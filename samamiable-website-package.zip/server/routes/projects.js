// routes/projects.js
const express = require("express");
const db = require("../db");
const { authenticate, requireAdmin } = require("../middleware/auth");

const router = express.Router();

function getFullProject(id) {
  const project = db.prepare("SELECT * FROM projects WHERE id = ?").get(id);
  if (!project) return null;
  const stages = db
    .prepare("SELECT title, description, image_url as imageUrl FROM project_stages WHERE project_id = ? ORDER BY position ASC")
    .all(id);
  const reviews = db
    .prepare("SELECT author, role, rating, quote FROM project_reviews WHERE project_id = ?")
    .all(id);
  return { ...project, isSample: !!project.is_sample, stages, reviews };
}

// GET /api/projects - public, used by the Portfolio page
router.get("/", (req, res) => {
  const rows = db.prepare("SELECT id FROM projects ORDER BY created_at DESC").all();
  res.json(rows.map((r) => getFullProject(r.id)));
});

// GET /api/projects/:id - public, used by the Portfolio detail view
router.get("/:id", (req, res) => {
  const project = getFullProject(req.params.id);
  if (!project) return res.status(404).json({ error: "Project not found." });
  res.json(project);
});

// Everything below this line is admin-only.
router.use(authenticate, requireAdmin);

const upsertStagesAndReviews = db.transaction((projectId, stages, reviews) => {
  db.prepare("DELETE FROM project_stages WHERE project_id = ?").run(projectId);
  db.prepare("DELETE FROM project_reviews WHERE project_id = ?").run(projectId);

  const insertStage = db.prepare(
    "INSERT INTO project_stages (project_id, position, title, description, image_url) VALUES (?, ?, ?, ?, ?)"
  );
  (stages || []).forEach((s, i) => insertStage.run(projectId, i, s.title || "", s.description || "", s.imageUrl || null));

  const insertReview = db.prepare(
    "INSERT INTO project_reviews (project_id, author, role, rating, quote) VALUES (?, ?, ?, ?, ?)"
  );
  (reviews || []).forEach((r) =>
    insertReview.run(projectId, r.author || "", r.role || "", Number(r.rating) || 5, r.quote || "")
  );
});

// POST /api/projects - create a new portfolio project (admin only)
router.post("/", (req, res) => {
  const { id, title, status, sector, service, location, year, description, stages, reviews } = req.body || {};
  if (!id || !title || !location) {
    return res.status(400).json({ error: "id, title, and location are required." });
  }

  db.prepare(
    `INSERT INTO projects (id, title, status, sector, service, location, year, description, is_sample)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)`
  ).run(id, title, status || "Planning", sector || null, service || null, location, year || null, description || null);

  upsertStagesAndReviews(id, stages, reviews);
  res.status(201).json(getFullProject(id));
});

// PUT /api/projects/:id - update an existing project (admin only)
router.put("/:id", (req, res) => {
  const existing = db.prepare("SELECT id FROM projects WHERE id = ?").get(req.params.id);
  if (!existing) return res.status(404).json({ error: "Project not found." });

  const { title, status, sector, service, location, year, description, stages, reviews } = req.body || {};
  db.prepare(
    `UPDATE projects SET title = ?, status = ?, sector = ?, service = ?, location = ?, year = ?, description = ?,
     updated_at = datetime('now') WHERE id = ?`
  ).run(title, status, sector, service, location, year, description, req.params.id);

  upsertStagesAndReviews(req.params.id, stages, reviews);
  res.json(getFullProject(req.params.id));
});

// DELETE /api/projects/:id - remove a project and its stages/reviews (admin only)
router.delete("/:id", (req, res) => {
  const info = db.prepare("DELETE FROM projects WHERE id = ?").run(req.params.id);
  if (info.changes === 0) return res.status(404).json({ error: "Project not found." });
  res.status(204).send();
});

module.exports = router;
