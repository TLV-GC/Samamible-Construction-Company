// routes/auth.js
const express = require("express");
const bcrypt = require("bcryptjs");
const db = require("../db");
const { signToken } = require("../middleware/auth");

const router = express.Router();

function publicUser(row) {
  return { id: row.id, name: row.name, email: row.email, phone: row.phone, company: row.company, role: row.role };
}

// POST /api/auth/signup
// Creates a new client account. Admin accounts are never created through
// this endpoint; see server/seed.js for provisioning the one admin account.
router.post("/signup", async (req, res) => {
  const { name, email, phone, company, password } = req.body || {};
  if (!name || !email || !password) {
    return res.status(400).json({ error: "Name, email, and password are required." });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: "Password must be at least 8 characters." });
  }

  const normalizedEmail = String(email).trim().toLowerCase();
  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(normalizedEmail);
  if (existing) {
    return res.status(409).json({ error: "An account with this email already exists." });
  }

  const passwordHash = await bcrypt.hash(password, 12);
  const info = db
    .prepare(
      "INSERT INTO users (name, email, phone, company, password_hash, role) VALUES (?, ?, ?, ?, ?, 'client')"
    )
    .run(name, normalizedEmail, phone || null, company || null, passwordHash);

  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(info.lastInsertRowid);
  const token = signToken(user);
  res.status(201).json({ token, user: publicUser(user) });
});

// POST /api/auth/login
// Logs in either a client or an admin account (role comes back in the
// token and response so the frontend can route accordingly).
router.post("/login", async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required." });
  }

  const normalizedEmail = String(email).trim().toLowerCase();
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(normalizedEmail);

  // Compare against a dummy hash when the user doesn't exist, so that
  // response timing doesn't reveal whether an email is registered.
  const hashToCompare = user ? user.password_hash : "$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinv";
  const valid = await bcrypt.compare(password, hashToCompare);

  if (!user || !valid) {
    return res.status(401).json({ error: "Email or password is incorrect." });
  }

  const token = signToken(user);
  res.json({ token, user: publicUser(user) });
});

module.exports = router;
