// routes/portal.js
const express = require("express");
const db = require("../db");
const { authenticate, requireAdmin } = require("../middleware/auth");

const router = express.Router();

/* ---- client project tracker (private to the logged-in client) ---- */

// GET /api/portal/projects - the current client's own tracked projects
router.get("/projects", authenticate, (req, res) => {
  if (req.user.role !== "client") return res.status(403).json({ error: "Client account required." });
  const rows = db
    .prepare("SELECT * FROM client_projects WHERE user_id = ? ORDER BY updated_at DESC")
    .all(req.user.id);
  res.json(rows);
});

// Admin-side: attach or update a tracked project for a given client, and
// review submitted quotes/applications/messages.
router.post("/clients/:userId/projects", authenticate, requireAdmin, (req, res) => {
  const { name, type, status, progress, location, nextMilestone, lastUpdate } = req.body || {};
  if (!name) return res.status(400).json({ error: "Project name is required." });

  const info = db
    .prepare(
      `INSERT INTO client_projects (user_id, name, type, status, progress, location, next_milestone, last_update)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(req.params.userId, name, type || null, status || "Planning", progress || 0, location || null, nextMilestone || null, lastUpdate || null);

  res.status(201).json(db.prepare("SELECT * FROM client_projects WHERE id = ?").get(info.lastInsertRowid));
});

router.put("/client-projects/:id", authenticate, requireAdmin, (req, res) => {
  const { name, type, status, progress, location, nextMilestone, lastUpdate } = req.body || {};
  db.prepare(
    `UPDATE client_projects SET name = ?, type = ?, status = ?, progress = ?, location = ?,
     next_milestone = ?, last_update = ?, updated_at = datetime('now') WHERE id = ?`
  ).run(name, type, status, progress, location, nextMilestone, lastUpdate, req.params.id);
  res.json(db.prepare("SELECT * FROM client_projects WHERE id = ?").get(req.params.id));
});

/* ---- public inquiry forms (quote requests, job applications, contact) ---- */

router.post("/quotes", (req, res) => {
  const { name, email, phone, service, clientType, state, budget, details } = req.body || {};
  if (!name || !email || !phone || !service || !details) {
    return res.status(400).json({ error: "Name, email, phone, service, and details are required." });
  }
  db.prepare(
    `INSERT INTO quotes (name, email, phone, service, client_type, state, budget, details)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(name, email, phone, service, clientType || null, state || null, budget || null, details);
  res.status(201).json({ ok: true });
});

router.post("/applications", (req, res) => {
  const { job, name, email, phone, message } = req.body || {};
  if (!name || !email || !phone) {
    return res.status(400).json({ error: "Name, email, and phone are required." });
  }
  db.prepare(
    "INSERT INTO applications (job_title, name, email, phone, message) VALUES (?, ?, ?, ?, ?)"
  ).run(job || null, name, email, phone, message || null);
  res.status(201).json({ ok: true });
});

router.post("/messages", (req, res) => {
  const { name, email, phone, message } = req.body || {};
  if (!name || !email || !message) {
    return res.status(400).json({ error: "Name, email, and message are required." });
  }
  db.prepare("INSERT INTO messages (name, email, phone, message) VALUES (?, ?, ?, ?)").run(name, email, phone || null, message);
  res.status(201).json({ ok: true });
});

/* ---- admin: read submitted inquiries ---- */

router.get("/quotes", authenticate, requireAdmin, (req, res) => {
  res.json(db.prepare("SELECT * FROM quotes ORDER BY submitted_at DESC").all());
});
router.get("/applications", authenticate, requireAdmin, (req, res) => {
  res.json(db.prepare("SELECT * FROM applications ORDER BY submitted_at DESC").all());
});
router.get("/messages", authenticate, requireAdmin, (req, res) => {
  res.json(db.prepare("SELECT * FROM messages ORDER BY submitted_at DESC").all());
});

module.exports = router;
