# Samamiable Construction Company — Website Package

This package has two parts that work together but run separately:

1. **`samamiable-website.jsx`** — the interactive demo you see rendered in the chat. This is
   the actual site design, copy, and every user flow (quote form, careers, blog, client
   portal, admin dashboard, portfolio). It runs entirely in the browser and uses a
   lightweight built-in storage system to simulate a backend, so you can click through
   everything right now without installing anything.
2. **`server/`** — a real, tested Node.js backend (accounts, password hashing, sessions,
   a proper database, admin-only routes) that a developer can deploy to make the site's
   accounts and data genuinely secure and permanent. This is what the demo's storage
   layer should be replaced with before the site handles real client data.

Why two separate things instead of one? The live preview in chat can only run a single
bundled file — there's no server behind it, so it can't run real backend code. Splitting
it this way means you get something you can click through today **and** a legitimate,
already-tested backend to hand to a developer for the real launch, instead of one or the
other.

---

## 1. The live demo (`samamiable-website.jsx`)

### Pages
Home, About, Services, Projects (portfolio), Careers, News, Contact, Client Portal, and a
hidden Admin dashboard.

### Client portal
Log in with the demo account shown on the login screen:
- **Email:** `demo@samamiable.com`
- **Password:** `demo1234`

Or create a new account — it will start with no linked projects, since new client accounts
don't have project history yet.

### Admin dashboard
Deliberately not in the main navigation. Access it via the small **"Admin"** link in the
footer, bottom-right, next to the copyright line. Log in with:
- **Username:** `admin`
- **Password:** `Samamiable@Admin1`

From there you can:
- Add, edit, or delete portfolio projects (title, status, sector, service, location, year,
  description)
- Add or remove **stages** for a project (title, description, and an optional image URL —
  there's no file upload in this demo environment, so paste a hosted image link once you
  have real project photos)
- Add or remove **client reviews** (author, role, star rating, quote)
- Browse every quote request, job application, and contact message submitted through the
  site

**Change this password before sharing the site link with anyone else**, since this demo
version's login is a client-side simulation, not a secure server-side login — see the
security note below.

### About the sample portfolio project
One project, "Sample Project — Ikoyi Waterfront Residence," is marked with a **Sample
project** tag and pre-loaded with example stages and example client reviews so you can see
the feature working end to end. It's clearly labeled as a placeholder rather than a real
company's work — publishing someone else's actual completed project under your name would
misrepresent your track record to potential clients, so rather than doing that, this
sample project is entirely original placeholder content. Edit or delete it from the admin
dashboard whenever you have a real project to put in its place.

### Your logo
The logo you uploaded (correctly spelled "Samamiable" this time) is embedded directly in
the header, the homepage hero, and the footer.

### Colors
Blue, white, and red, pulled from the logo itself so the site matches the emblem rather
than introducing different tones.

### Important limitation: this demo's "backend" is not secure
Everything in the demo — client accounts, admin login, submitted forms — is stored in the
browser-based storage the preview environment provides. It works, and it persists, but:
- Passwords are stored in plain text, not hashed
- Anyone who inspects the page could potentially read stored data
- There's no real server validating requests

This is normal and expected for a **live design and functionality preview** — it is not
appropriate for real client data. That's exactly what the `server/` folder below replaces.

---

## 2. The backend (`server/`)

A genuine Express + SQLite backend, already written and **already tested end-to-end**
(signup, login, wrong-password rejection, admin-only routes correctly blocking a
non-admin token, project creation, and quote submission all verified working before this
was handed to you).

### What's solid about it
- Passwords hashed with **bcrypt** (12 rounds), never stored in plain text
- Sessions handled with signed **JWTs**, expiring after 7 days
- Every database query is **parameterized** (no SQL injection risk)
- Admin-only routes are protected by real server-side role checks, not just a hidden link
- Login responses don't reveal whether an email is registered (timing-safe comparison)

### File structure
```
server/
  index.js              Express app entry point
  db.js                 SQLite schema (users, projects, stages, reviews, quotes, applications, messages)
  seed.js                Creates the one admin account + the sample project
  middleware/auth.js     JWT verification + admin-role gate
  routes/auth.js         POST /api/auth/signup, /api/auth/login
  routes/projects.js     GET (public) + POST/PUT/DELETE (admin) for portfolio projects
  routes/portal.js       Client project tracker, and quote/application/contact form endpoints
  .env.example           Every environment variable you need to set, documented
```

### Running it
```
cd server
npm install
cp .env.example .env
```
Open `.env` and set:
- `JWT_SECRET` — generate one with `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`
- `ADMIN_EMAIL` / `ADMIN_PASSWORD` — the real admin login you want

Then:
```
npm run seed     # creates the admin account and the sample project, once
npm start        # starts the API on http://localhost:4000
```

### API reference (short version)
| Method | Route | Who | What |
|---|---|---|---|
| POST | `/api/auth/signup` | Public | Create a client account |
| POST | `/api/auth/login` | Public | Log in (client or admin — role comes back in the response) |
| GET | `/api/projects` | Public | List all portfolio projects with stages + reviews |
| GET | `/api/projects/:id` | Public | One project, full detail |
| POST / PUT / DELETE | `/api/projects/:id` | Admin | Manage portfolio projects |
| GET | `/api/portal/projects` | Client (own only) | The logged-in client's tracked projects |
| POST | `/api/portal/quotes` \| `/applications` \| `/messages` | Public | Submit the quote / careers / contact forms |
| GET | `/api/portal/quotes` \| `/applications` \| `/messages` | Admin | Review everything submitted |

### Connecting the live site to this backend
The demo site currently talks to the browser's built-in storage. To go live for real, a
developer would host this `server/` folder (Render, Railway, a small VPS, etc.), then
update the site's storage calls to call these API routes instead — signup/login calls
become `fetch('/api/auth/...')`, the stored JWT gets sent as an `Authorization: Bearer`
header on every request after that, and admin/portfolio actions call the matching
`/api/projects` routes. The page structure, design, and every user flow stay exactly the
same; only where the data is read from and written to changes.

### Before this goes live
- Change the seeded admin password immediately after first login
- Put a real, verified `JWT_SECRET` in production (never reuse the example)
- Move from SQLite to a hosted database if you expect heavy concurrent traffic (SQLite
  handles a national contractor site's normal load fine; swap `db.js` for Postgres later
  if you need to)
- Get a real vector/flat version of the logo made — the current one is a detailed
  photorealistic mockup, which works for a hero image but isn't ideal at very small sizes
  (favicon, mobile nav)
- Replace all sample/placeholder content (projects, reviews, blog posts, job listings)
  with real information as it becomes available
